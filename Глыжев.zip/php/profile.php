<?php
session_start();
if (!$_SESSION['user']) {
    header('Location: /');
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Авторизация и регистрация</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body id="body">
    <!-- Профиль -->
    <div>
        <p>
            <?php
                print $_COOKIE['user'];
            ?>
        </p>
    </div>
    <div class="menu" id="menu">
    <div class="name">
      FLY ACROSS<br>THE SKY
    </div>
    <button class="play" onclick="mygame()">▶ Play</button>
    <img src="img/sound.png" width="40" height="40" alt="" id="volume" onclick="off_on()">
    <div class="logout"><a href="vendor/logout.php" class="logout">Выход</a></div>

    <script src="js/game.js"></script>
</body>
</html>