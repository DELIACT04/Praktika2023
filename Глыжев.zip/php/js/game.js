// Звуковые файлы
var k = 0;

var fly = new Audio();
var score_audio = new Audio();
fly.src = "audio/fly.mp3";
score_audio.src = "audio/score.mp3";

var bird = new Image();
var bg = new Image();
var fg = new Image();
var pipeUp = new Image();
var pipeBottom = new Image();
bird.src = "img/bird2.png";
bg.src = "img/bg.png";
fg.src = "img/fg.png";
pipeUp.src = "img/pipeUp.png";
pipeBottom.src = "img/pipeBottom.png";

var i = 0;
var image = document.getElementById("volume");
var imgs = new Array('img/sound.png', 'img/sound_off.png');

var gap = 90;
var pipe = [];
pipe[0] = {
    x: 288,
    y: 0
}

var score = 0;
var maxscore = 0;

// Позиция птички
var xPos = 10;
var yPos = 150;

var t = 0;
var V = 0;
var grav = 0.005;

function off_on() { //вкл выкл звука
    i++;
    if (i == 2) i = 0;
    image.src = imgs[i];
    if (fly.volume == 1.0) fly.volume = 0.0; else fly.volume = 1.0;
    if (score_audio.volume == 1.0) score_audio.volume = 0.0; else score_audio.volume = 1.0;
}

function moveUp() { //прыжок птицы
    if (k==0) {
        V = -2;
        t = 0;
        fly.stop();
        fly.play();
    }
}

function mygame() {
    var menu = document.getElementById("menu");
    menu.remove();

    var option = document.createElement("img");
    option.src = "img/option.png";
    option.id = "option";
    option.onclick = function () { //пауза
        option.remove();
        cvs.remove();
        k = 1;
        var pause = document.createElement("div");
        pause.className = "menu";
        pause.id = "menu";
        let name = document.createElement("div");
        name.className = "name1";
        name.textContent = "Pause";
        let butCont = document.createElement("button");
        butCont.className = "play";
        butCont.textContent = "Continue";
        butCont.onclick = function() { //возобновить игру
            k=0;
            mygame();
        }
        let butMain = document.createElement("button");
        butMain.className = "play";
        butMain.textContent = "Main menu";
        butMain.onclick = function() { //выход в главное меню
            location.reload();
        }
        pause.appendChild(name);
        pause.appendChild(butCont);
        pause.appendChild(butMain);
        pause.appendChild(image);
        body.appendChild(pause);
    }

    body.appendChild(option);

    var cvs = document.createElement("canvas");
    cvs.id = "canvas";
    cvs.height = 512;
    cvs.width = 288;
    document.body.appendChild(cvs);
    var ctx = cvs.getContext("2d");


    // При нажатии на какую-либо кнопку
    document.addEventListener("keydown", moveUp);

    HTMLAudioElement.prototype.stop = function () { //функция остановки музыки
        this.pause();
        this.currentTime = 0.0;
    }


    function draw() {
        if (yPos <= 0) yPos = 0;
        if (k === 0) {
            ctx.drawImage(bg, 0, 0);
    
            for (let i = 0; i < pipe.length; i++) {
                const currentPipe = pipe[i];
                ctx.drawImage(pipeUp, currentPipe.x, currentPipe.y);
                ctx.drawImage(pipeBottom, currentPipe.x, currentPipe.y + pipeUp.height + gap);
                
                currentPipe.x--;
    
                if (currentPipe.x === 125) {
                    pipe.push({
                        x: cvs.width,
                        y: Math.floor(Math.random() * pipeUp.height / 1.5 + 50) - pipeUp.height + 10,
                    });
                }
    
                if (currentPipe.x === 5) {
                    score++;
                    if (score > maxscore) {
                        maxscore = score;
                    }
                    score_audio.play();
                }
    
                // Отслеживание прикосновений
                if (
                    xPos + bird.width >= currentPipe.x &&
                    xPos <= currentPipe.x + pipeUp.width &&
                    (yPos <= currentPipe.y + pipeUp.height ||
                        yPos + bird.height >= currentPipe.y + pipeUp.height + gap) ||
                    yPos + bird.height >= cvs.height - fg.height
                ) {
                    resetGame();
                }
            }
    
            ctx.drawImage(fg, 0, cvs.height - fg.height);
            ctx.drawImage(bird, xPos, yPos);
            V += t * grav;
            yPos += V;
            t++;
    
            ctx.fillStyle = "#000";
            ctx.font = "24px Verdana";
            ctx.fillText("Score: " + score, 10, cvs.height - 40);
            ctx.fillText("Max score: " + maxscore, 10, cvs.height - 20);
    
            requestAnimationFrame(draw);
        }
    }
    
    function resetGame() { //рестарт игры
        pipe.length = 0;
        pipe[0] = {
            x: cvs.width,
            y: 0,
        };
        xPos = 10;
        yPos = 150;
        score = 0;
        t = 0;
    }

    draw();
}
